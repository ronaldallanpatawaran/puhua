<?php
// Heading
$_['heading_title']        = 'OpenCart';

// Text

			////
					$_['heading_title_2'] = 'Assign Super Ninja Admin';
					$_['heading_title_av'] = 'Available Admin Groups';
					$_['heading_title_user'] = 'Available Admin Users';
					$_['heading_title_superuser'] = 'SET Super Ninja Admin';
					$_['text_group_id'] = 'Group ID :';
					$_['text_group_name'] = 'Group Name :';
					$_['text_user_id'] = 'User ID :';
					$_['text_username_ad'] = 'Username :';
					$_['text_view'] = 'View';
					$_['text_error'] = 'The page you are looking for cannot be found.';
			////
			
$_['text_order']           = 'Orders';
$_['text_order_status']    = 'Pending';
$_['text_complete_status'] = 'Completed';
$_['text_customer']        = 'Customers';
$_['text_online']          = 'Customers Online';
$_['text_approval']        = 'Pending approval';
$_['text_product']         = 'Products';
$_['text_stock']           = 'Out of stock';
$_['text_review']          = 'Reviews';
$_['text_return']          = 'Returns';
$_['text_affiliate']       = 'Affiliates';
$_['text_store']           = 'Stores';
$_['text_front']           = 'Store Front';
$_['text_help']            = 'Help';
$_['text_homepage']        = 'Homepage';
$_['text_support']         = 'Support Forum';
$_['text_documentation']   = 'Documentation';
$_['text_logout']          = 'Logout';