<?php
// Text
$_['text_error'] = 'Information Page Not Found!';
$_['text_company_profile'] = 'Company Profile';
$_['text_our_benefits'] = 'Our Benefits';
$_['text_certifications'] = 'Certifications';
$_['text_testimonials'] = 'Testimonials';
$_['text_see_more'] = "See More";


$_['text_benefits_1'] = 'Prevent Mould &amp; Balance PH Value';
$_['text_benefits_2'] = 'No Chemicals &amp; Eliminates VOC';
$_['text_benefits_3'] = 'Release Negative Ions';
$_['text_benefits_4'] = 'Flame Resistant';
$_['text_benefits_5'] = 'Anti Bacterias';
$_['text_benefits_6'] = 'Eliminates Smoke';
$_['text_benefits_7'] = 'Saves Energy';
$_['text_benefits_8'] = 'Sound Absorption';