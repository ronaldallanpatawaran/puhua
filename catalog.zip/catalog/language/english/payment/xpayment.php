<?php
// Text
$_['text_title']       = 'X-Payment';
$_['text_payment_instruction']       = 'Payment Instruction';
$_['text_description'] = 'X-Payment - Create your own custom payment';
?>