<?php
// Heading
$_['heading_title']         = 'eNETS Payment (Credit)';

// Text
$_['text_title']            = 'eNETS - VISA and Master Credit Card only';
$_['text_payment_failed']   = 'Your payment has failed. No transaction has been made. Please contact the shop administrator for assistance or use a different payment option.';
$_['text_checkout']			= 'Checkout';
?>