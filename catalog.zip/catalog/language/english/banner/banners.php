<?php 
	
$_['text_contacts'] 			= 'Contact Us';
$_['text_aboutus'] 				= 'About Us';