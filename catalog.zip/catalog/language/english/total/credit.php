<?php
$_['text_credit']   = 'Store Credit';
$_['text_order_id'] = 'Order ID: #%s';