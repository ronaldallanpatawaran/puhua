<?php
// Heading
$_['heading_title']    = 'Articles Archive';
$_['button_headlines'] = 'Headlines';