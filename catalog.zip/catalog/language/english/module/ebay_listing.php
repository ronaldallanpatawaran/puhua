<?php
$_['heading_title'] = 'On our eBay store';