<?php
// Text
$_['text_image']	= 'Image';
$_['text_name']		= 'Product Name';
$_['text_quantity']	= 'Quantity';
$_['text_price']	= 'Unit Price';
$_['text_total']	= 'Total';