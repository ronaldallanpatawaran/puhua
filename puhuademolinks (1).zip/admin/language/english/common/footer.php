<?php
// Text
$_['text_footer'] 	= 'Powered by Firstcom Solutions';
$_['text_version'] 	= 'Version %s';